import os

def check_supplier_exists(supplier_number):
    SUPPLIERS = load_suppliers()
    return bool(SUPPLIERS.get(f'Sup{supplier_number}', False))

def adding(): 
    print("  /=========================\ "+"\n"
           "\n   <||    Item List       ||>" + "\n\n"+ 
           "   <||  HC - Head Cover   ||>" + "\n"+
           "   <||  FS - Face Shield  ||>" + "\n"+
           "   <||  MS - Mask         ||>" + "\n"+
           "   <||  GL - Gloves       ||>" + "\n"+
           "   <||  GW - Gown         ||>" + "\n"+
           "   <||  SC - Shoe Covers  ||>"+"\n"
           "  \=========================/ ")

    while True:
        item = input("\n   Enter an item(code or name): ").upper()

        with open('ppe.txt', 'r') as f:
            if item in f.read():
                print("   This item is already supplied")
                continue

        supplier = int(input("   Choose supplier from 1 to 4: "))
        if supplier < 1 or supplier > 4 or not check_supplier_exists(supplier):
            print("   Invalid supplier. Choose from 1 to 4 and make sure supplier exists.")
            continue

        with open("ppe.txt", 'a') as item_file:
            item_file.write(f"{item} === Sup{str(supplier)} === 100\n")

        more = input("   Do you want to continue(y/n)? ").lower()
        if more == 'n' or more == 'no':
            return
        elif more == 'y' or more == 'yes':
            continue
        else:
            print("Something went wrong... Please try again")
            return

def deducting():
    while True:  
        option = input("\n"+
                        "<|| 1 - Receive    ||> "+"\n"+
                        "<|| 2 - Distribute ||>"+"\n"+
                        "\n   Please choose the option: ")

        if option == "1":
            with open("ppe.txt", 'r') as it_fl:
                lines = it_fl.readlines()
                item = input("   Enter an item to supply: ").upper()
                for i in range(len(lines)):
                    if item in lines[i]:
                        get_qty = lines[i].split("===")[-1].strip()
                        add_qty = int(input("   How much to be supplied? "))
                        item_qty = int(get_qty) + add_qty            
                        lines[i] = lines[i].replace(get_qty, str(item_qty))
                        break

                with open("ppe.txt", 'w') as it_fl:
                    it_fl.writelines(lines)
                    inventory()

        elif option == '2':                                           
            with open("ppe.txt", 'r') as it_fl:    
                lines = it_fl.readlines()
                item = input("   Enter an item to distribute: ").upper()
                distributed = 0
                for i in range(len(lines)):
                    if item in lines[i]:
                        get_qty = lines[i].split("===")[-1].strip()
                        sub_qty = int(input("   How much to be distributed? "))
                        if int(get_qty) >= sub_qty:
                            item_qty = int(get_qty) - sub_qty    
                            distributed = sub_qty
                            lines[i] = lines[i].replace(get_qty, str(item_qty))
                            hospital_code = input("   Enter the hospital code for distribution: ")
                            with open("distribution.txt", 'a+') as dis_fl:
                                dis_fl.write(f"{item} === {hospital_code} === {distributed}\n")
                        else:
                            print("   Insufficient quantity in stock")                    
                            print(f"   You only have {get_qty} items")
                        break

                with open("ppe.txt", 'w') as it_fl:
                    it_fl.writelines(lines)
                    print(f"\n   Distributed hospital code: {hospital_code}")
                    print(f"   Item distributed: {item}")
                    print(f"   Quantity distributed: {distributed}")

        else:
            print("   Something went wrong... Please try again")
            return

def total():
    while True:
        print("\n   || Do you want to view Total PPEs or an item code? ||\n")     
        option = input("\n"+
                "   <|| 1 - total           ||> "+"\n"+
                "   <|| 2 - Enter Item Code ||>"+"\n"+
                "   <|| 3 - Back            ||>"+"\n"+
                " \n   Please choose the option: ").upper()
        
        if option == '1':
            with open('ppe.txt', 'r') as f:
                total = 0
                for line in f:
                    quantity = int(line.split("===")[-1])
                    total += quantity
                print("\n   ========================================="
                +f"\n   <||   TOTAL NUMBER OF PPEs IN STOCK    ||>"
                +f"\n   <||   Total PPEs: {total}                  ||>"
                +"\n   =========================================")

        elif len(option) == 2: 
            with open('ppe.txt', 'r') as f:
                total = 0
                for line in f:
                    if option in line:
                        quantity = int(line.split("===")[-1])
                        total += quantity
                print(f"\n   ========================================"
                +f"\n   <||   TOTAL NUMBER OF {option} IN STOCK    ||>"
                +f"\n   <||   Total {option}: {total}                  ||>"
                +"\n   ========================================")
        elif option == "3":
            menu()
        else:
            print("   Invalid option. Please enter again.")
            total()
        
def check():
    with open("ppe.txt", 'r') as it_fl:
        for line in it_fl.readlines():
            item, supplier, quantity = line.strip().split(' === ')
            print("\n   ======================================================"
                  +f"\n   <||   Item: {item:2}   Supplier: {supplier:2}   Quantity: {quantity:2}    ||>"
                  +"\n   ======================================================")
    menu()

def search():
            i_code = input("\n   Please enter the item code: ").upper()
            with open("distribution.txt", "r") as it:
                lines = it.readlines()
                for line in lines:
                    info = line.split(" === ")
                    if i_code == info[0]:
                        item = info[0]
                        hos_name = info[1]
                        q_ty = info[2]
                        if i_code == item:
                            print(f"   Item Code: {item}\n   Hospital code: {hos_name}\n   Distributed: {q_ty}\n")
                        else:
                            print("   Something went wrong, please try again")
                        it.close()
                        menu()

def updateData():
    option = input("\n   <|| 1 - Update all data    ||>\n"+
                   "   <|| 2 - Back               ||>\n" 
                   "\n   Choose option: ")

    if option == "1":
        open("suppliers.txt", "w").close()
        open("ppe.txt", "w").close()
        open("hospitals.txt", "w").close()
        open("distribution.txt", "w").close()
        menu()
    if option == "2":
        menu()    

def load_suppliers():
    SUPPLIERS = {"Sup1": [], "Sup2": [], "Sup3": [], "Sup4": []}
    if not os.path.isfile("suppliers.txt"):
        with open("suppliers.txt", "a+") as file:
            for key in SUPPLIERS.keys():
                file.write(f"{key} | \n")
    else:
        with open("suppliers.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                info = line.strip().split(" | ")
                if len(info) > 1:
                    SUPPLIERS[info[0]] = info[1:]
    return SUPPLIERS

def supplier(): 
    HOSPITALS = ["Hosp1", "Hosp2", "Hosp3", "Hosp4"]
    SUPPLIERS = load_suppliers()
    option = input("\n"+
                    "   <|| 1 - Create new supplier ||>"+"\n"+
                    "   <|| 2 - Check supplier      ||>"+"\n"+
                    "\n   Please choose the option: ")
    if option.lower() == "1":
        while True:
            sup = 'Sup' + input("\n   Create new supplier"+
                "\n   Choose number from 1 to 4: ")
            if sup not in SUPPLIERS or SUPPLIERS[sup]:
                print("   This supplier is already in the list or not valid\n")
                continue
            else:
                sup_name = input("\n   Enter the supplier's name: ")
                sup_number = input("   Enter the supplier's phone number: ")
                sup_address = input("   Enter the supplier's address: ")

                SUPPLIERS[sup] = [sup_name, sup_number, sup_address]

                with open("suppliers.txt", "w") as file:
                    for key, values in SUPPLIERS.items():
                        file.write(f"{key} | {' | '.join(values)}\n")

                print("\n   Supplier has been added to the list\n"
                    "\n   - Supplier code   : ", sup + "\n"+
                      "   - Supplier name   : ", sup_name + "\n"+
                      "   - Supplier number : ", sup_number + "\n"+
                      "   - Supplier address: ", sup_address + "\n")
                inventory()
                break

    elif option.lower() == "2":
        s_code = input("\n   Please enter supplier code: ")
        if s_code in SUPPLIERS and SUPPLIERS[s_code]:
            sup_name = SUPPLIERS[s_code][0]
            sup_number = SUPPLIERS[s_code][1]
            sup_address = SUPPLIERS[s_code][2]

            print(f"\n | Supplier Code: {s_code}\n | Supplier name: {sup_name}\n | Supplier number: {sup_number}\n | Supplier address: {sup_address}\n ")
            inventory()
        else:
            print("   Invalid supplier code. Please try again.")

def load_hospitals():
    HOSPITALS = {"Hosp1": [], "Hosp2": [], "Hosp3": [], "Hosp4": []}
    if not os.path.isfile("hospitals.txt"):
        with open("hospitals.txt", "a+") as file:
            for hospital in HOSPITALS.keys():
                file.write(f"{hospital} | \n")
    else:
        with open("hospitals.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                info = line.strip().split(" | ")
                if len(info) > 1:
                    HOSPITALS[info[0]] = info[1:]
    return HOSPITALS

def hospital():
    HOSPITALS = load_hospitals()
    option = input("\n"+
                    "   <|| 1 - Create new hospital ||>"+"\n"+
                    "   <|| 2 - Check hospital      ||>"+"\n"+
                    "     Please choose the option: ")
    if option.lower() == "1":
        while True:
            hosp_code = 'Hosp' + input("\n   Create new hospital"+
                "\n   Choose number from 1 to 4: ")
            if hosp_code not in HOSPITALS or HOSPITALS[hosp_code]:
                print("\n   This hospital is already in the list or not valid\n")
                continue
            else:
                hosp_name = input("\n   Enter the hospital's name: ")
                hosp_address = input("   Enter the hospital's address: ")

                HOSPITALS[hosp_code] = [hosp_name, hosp_address]

                with open("hospitals.txt", "w") as file:
                    for key, values in HOSPITALS.items():
                        file.write(f"{key} | {' | '.join(values)}\n")

                print("\n   Hospital has been added to the list\n"
                    "\n   - Hospital code   : ", hosp_code + "\n"+
                      "   - Hospital name   : ", hosp_name + "\n"+
                      "   - Hospital address: ", hosp_address + "\n")
                inventory()
                break

    elif option.lower() == "2":
        h_code = input("\n   Please enter hospital code: ")
        if h_code in HOSPITALS and HOSPITALS[h_code]:
            hosp_name = HOSPITALS[h_code][0]
            hosp_address = HOSPITALS[h_code][1]

            print(f"\n | Hospital Code: {h_code}\n | Hospital name: {hosp_name}\n | Hospital address: {hosp_address}\n ")
            inventory()
        else:
            print("   Invalid hospital code. Please try again.")

def inventory():
    while True:
        print("\n\n    /=========================\ "+"\n"+
            "    You've entered to Inventory "+"\n"+
            "    \=========================/ "+"\n\n"+
            "   <|| 1 - Adding            ||>" + "\n"+
            "   <|| 2 - Deducting         ||>" + "\n"+
            "   <|| 3 - Suppliers details ||>" + "\n"+
            "   <|| 4 - Hospital details  ||>" + "\n"+
            "   <|| 5 - Back              ||>" + "\n"+
            "     |=======================| ")
        
        ans = int(input("\n   Choose option from 1 to 5: "))
        if ans == 1:
            adding()
        elif ans == 2:
            deducting()
        elif ans == 3:
            supplier()
        elif ans == 4:
            hospital()
        elif ans == 5:
            break
        else:
            print("Error")
            continue
        
def menu():
    while True:
        print("    /==========================\\"+""
              "\n   <||      Main Menu         ||>" + "\n"+ 
              "   <|| 1 - Inventory          ||>" + "\n"+
              "   <|| 2 - Inventory Tracking ||>" + "\n"+
              "   <|| 3 - Search             ||>" + "\n"+
              "   <|| 4 - Check Inventory    ||>" + "\n"+
              "   <|| 5 - Data Update        ||>" + "\n"
              "   <|| 6 - Exit               ||>" + "\n"
              "    \==========================/ ")
        option = int(input("\n   Choose option from 1 to 6: "))
        if option == 1:
            inventory()
        elif option == 2:
            total()
        elif option == 3:
            search()
        elif option == 4:
            check()
        elif option == 5:
            updateData()
        elif option == 6:
            print("Exiting the program")
            break
        else:
            print("Invalid option. Please enter again.")

menu()